// Copyright 2012 - 2013 The Eco Authors. All rights reserved. See the LICENSE file.

// Package smp implements functions to sample from species population density.
package smp
