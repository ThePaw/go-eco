package ser

import (
	"encoding/csv"
	"fmt"
	"io"
	"os"
	"strconv"
)

// IntMatrix is 2D array of integers. Elements are stored in a single int slice and slices of each row are created.

type IntMatrix [][]int

// NewIntMatrix creates a new IntMatrix instance with specified number of rows and columns
func NewIntMatrix(nRow, nCol int) IntMatrix {
	s := make([]int, nCol*nRow)
	mat := make(IntMatrix, nRow)
	for i, p := 0, 0; i < nRow; i++ {
		mat[i] = s[p : p+nCol]
		p += nCol
	} // for i

	return mat
}

// Dims return the dimensions of the matrix.
func (m IntMatrix) Dims() (int, int) {
	return len(m), len(m[0])
}

// Rows returns the number of rows
func (m IntMatrix) Rows() int {
	return len(m)
}

// Cols returns the number of columns
func (m IntMatrix) Cols() int {
	if len(m) == 0 {
		return 0
	}

	return len(m[0])
}

// Copy to an existing matrix
func (m IntMatrix) Copy(targetMat IntMatrix) {
	n := m.Rows() * m.Cols()
	if n > 0 {
		copy(targetMat[0][:n], m[0][:n])
	}
	return
}

// Clone clones an IntMatrix
func (m IntMatrix) Clone() IntMatrix {
	mat := NewIntMatrix(m.Rows(), m.Cols())

	n := m.Rows() * m.Cols()
	if n > 0 {
		copy(mat[0][:n], m[0][:n])
	}

	return mat
}

/*
func (m IntMatrix) Fill(vl int) {
    n := m.Rows() * m.Cols()
    IntSlice(m[0][:n]).Fill(0, n, vl)
}
*/

// Swap rows i, j
func (m IntMatrix) SwapRows(i int, j int) {
	cols := m.Cols()
	for k := 0; k < cols; k++ {
		x := m[i][k]
		m[i][k] = m[j][k]
		m[j][k] = x
	}
}

// Swap columns i, j
func (m IntMatrix) SwapCols(i int, j int) {
	rows := m.Rows()
	for k := 0; k < rows; k++ {
		x := m[k][i]
		m[k][i] = m[k][j]
		m[k][j] = x
	}
}

// ReadCsvIntMatrix  reads the matrix from an opened CSV file. 
func ReadCsvIntMatrix(f *os.File) (m IntMatrix) {
	read := csv.NewReader(io.Reader(f))
	data, err := read.ReadAll()
	if err != nil {
		panic("Failed to read from the CSV File(Maybe the file does not comply to the CSV standard defined in RFC 4180)")
	}

	rows := len(data)
	cols := len(data[0])
	m = NewIntMatrix(rows, cols)
	for i := 0; i < rows; i++ {
		for j := 0; j < cols; j++ {
			x, _ := strconv.ParseInt(data[i][j], 10, 32) // why this is not int??
			m[i][j] = int(x)
		}
	}
	return
}

/*
func (m IntMatrix) WriteCSV(f *os.File)  {
	// to be implemented
	write := csv.NewWriter(io.Writer(f))
	records := // [][]string TO BE IMPLEMENTED
	rows, cols := m.Dims()
	for i := 0; i < rows; i++ {
		for j := 0; j < cols; j++ {
			records[i][j] = strconv.FormatInt(m[i][j], 10)
		}
	}
	err :=WriteAll(records)
	if err != nil {
		fmt.Println("Failed to write the CSV File")
	}
}
*/

func (m IntMatrix) WriteCSV() {
	rows, cols := m.Dims()
	for i := 0; i < rows; i++ {
		for j := 0; j < cols; j++ {
			if j == 0 {
				fmt.Print(m[i][j])
			} else {
				fmt.Print(",", m[i][j])
			}
		}
		fmt.Println()
	}
}

func (m IntMatrix) Print() {
	rows, cols := m.Dims()
	for i := 0; i < rows; i++ {
		for j := 0; j < cols; j++ {
			fmt.Printf("%d ", m[i][j])
		}
		fmt.Println()
	}
}

// PrettyString returns a pretty string form of the matrix
func (m IntMatrix) PrettyString() string {
	sa := make([][]string, 0, m.Rows())
	for _, row := range m {
		sr := make([]string, 0, len(row))
		for _, cell := range row {
			sr = append(sr, fmt.Sprint(cell))
		} // for cell
		sa = append(sa, sr)
	} // for row

	wds := make([]int, m.Cols())
	for j := 0; j < m.Cols(); j++ {
		for i := 0; i < m.Rows(); i++ {
			if len(sa[i][j]) > wds[j] {
				wds[j] = len(sa[i][j])
			} //  if
		} // for i
	} // for i

	res := ""
	for i, row := range sa {
		if i == 0 {
			res += "["
		} else {
			res += " "
		} // else
		res += "["
		for j, cell := range row {
			if j > 0 {
				res += " "
			} // if
			res += fmt.Sprintf(fmt.Sprintf("%%%ds", wds[j]), cell)
		} // for j, cell
		res += "]"
		if i == len(sa)-1 {
			res += fmt.Sprintf("](%dx%d)", m.Rows(), m.Cols())
		} // else
		res += "\n"
	} // for row

	return res
}

// Product computes the product of two matrices. 
func (a IntMatrix) Product(b IntMatrix) IntMatrix {
	rows, cols := a.Dims()
	c := NewIntMatrix(rows, cols)
	for i := 0; i < rows; i++ {
		for j := 0; j < cols; j++ {
			c[i][j] = 0
			for k := 0; k < cols; k++ {
				c[i][j] += a[i][k] * b[k][j]
			}
		}
	}
	return c
}

// CircleProduct computes circular product of two matrices. 
func (a IntMatrix) CircleProduct(b IntMatrix) IntMatrix {
	rows, cols := a.Dims()
	c := NewIntMatrix(rows, cols)
	for i := 0; i < rows; i++ {
		for j := 0; j < rows; j++ {
			c[i][j] = 0
			for k := 0; k < cols; k++ {
				c[i][j] += imin(a[i][k], b[k][j])
			}
		}
	}
	return c
}

// Transpose returns transposed matrix. 
func (a IntMatrix) Transpose() IntMatrix {
	rows, cols := a.Dims()
	c := NewIntMatrix(cols, rows)
	for i := 0; i < rows; i++ {
		for j := 0; j < cols; j++ {
			c[j][i] = a[i][j]
		}
	}
	return c
}

// IsSquare tests whether the matrix is square matrix. 
func (a IntMatrix) IsSquare() bool {
	q := true
	rows, cols := a.Dims()
	if rows != cols {
		q = false
	}
	return q
}

// IsSymmetric tests whether the square matrix is symmetric. 
func (a IntMatrix) IsSymmetric() bool {

	if !a.IsSquare() {
		panic("not a square matrix")
	}

	rows, cols := a.Dims()
	q := true
	for i := 0; i < rows && q; i++ {
		for j := 0; j < cols && q; j++ {
			if a[i][j] != a[j][i] {
				q = false
			}
		}
	}
	return q
}

// IsQ tests whether the matrix is a Q-matrix (columnwise). 
// See Kendall, 1971, for definition.
func (a IntMatrix) IsQ() bool {
	rows, cols := a.Dims()
	q := true
	for j := 0; j < cols && q; j++ {
		//find peak in column j
		peak := -999
		peakPos := 0
		for i := 0; i < rows; i++ {
			if a[i][j] >= peak {
				peak = a[i][j]
				peakPos = i

			} else {
				break
			}
		}

		// now test whether further is nonincreasing
		for i := peakPos + 1; i < rows && q; i++ {
			if a[i][j] > a[i-1][j] {
				q = false
			}
		}
	}
	return q
}

// IsR tests whether the square matrix is a R-matrix (Robinson, columnwise). 
// See Kendall, 1971, for definition.
func (a IntMatrix) IsR() bool {
	q := a.IsSymmetric()
	if q {
		q = a.IsQ()
	}
	return q
}

// CirclePower computes circular power of a matrix. 
// See Kendall, 1971: 111, for definition.
func (a IntMatrix) CirclePower(n int) IntMatrix {
	// S0
	w := a.Clone()
	t := w.Transpose()
	s := w.CircleProduct(t)
	for i := 1; i < n; i++ { // S1 ... Sn
		t = s.Transpose()
		s = s.CircleProduct(t)
	}
	return s
}
