// Copyright 2012 - 2013 The Eco Authors. All rights reserved. See the LICENSE file.

// Package aux implements auxilliary functions.
package aux
