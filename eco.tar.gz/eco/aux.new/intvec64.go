package ser

import (
	"fmt"
	"math/rand"
)

type IntVector64 []int64

// NewIntVector64 creates a new IntVector64 instance with specified number of elements
func NewIntVector64(nElem int) IntVector64 {
	v := make([]int64, nElem)
	return v
}

// Len returns number of elements in the vector
func (v IntVector64) Len() int {
	return len(v)
}

// Copy to an existing vector
func (v IntVector64) Copy(w IntVector64) {
	n := v.Len()
	if n > 0 {
		for i := 0; i < n; i++ {
			v[i] = w[i]
		}
	}
}

// Clone to a new vector
func (v IntVector64) Clone(w IntVector64) {
	n := v.Len()
	if n > 0 {
		w := NewIntVector64(n)
		for i := 0; i < n; i++ {
			v[i] = w[i]
		}
	}
}

// Swap elements i, j
func (v IntVector64) Swap(i, j int) {
	x := v[i]
	v[i] = v[j]
	v[j] = x
}

// Create ordered sequence 0 .. n. 
func (v IntVector64) Order() {
	n := v.Len()
	for i := 0; i < n; i++ {
		v[i] = int64(i)
	}
}

// Permute the vector randomly. 
func (v IntVector64) Perm() {
	n := v.Len()
	for j := 0; j < 20; j++ { // the '20' constant is ugly, but it works for me now
		for i := 0; i < n; i++ {
			v.Swap(i, i+rand.Intn(n-i))
		}
	}
}

func (v IntVector64) ReadCSV() {
	// to be implemented
}

func (v IntVector64) WriteCSV() {
	// to be implemented
}

func (v IntVector64) Print() {
	for i := 0; i < len(v); i++ {
		fmt.Printf("%d ", v[i])
	}
	fmt.Print("\n")
}
