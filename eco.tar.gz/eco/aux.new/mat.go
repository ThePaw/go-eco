package ser

import (
	"encoding/csv"
	"fmt"
	"io"
	"os"
	"strconv"
)

// Matrix64 is 2D array of float64. Elements are stored in a single float64 slice and slices of each row are created.

type Matrix64 [][]float64

// NewMatrix64 creates a new Matrix64 instance with specified number of rows and columns
func NewMatrix64(nRow, nCol int) Matrix64 {
	s := make([]float64, nCol*nRow)
	mat := make(Matrix64, nRow)
	for i, p := 0, 0; i < nRow; i++ {
		mat[i] = s[p : p+nCol]
		p += nCol
	} // for i

	return mat
}

// Rows returns the number of rows
func (m Matrix64) Rows() int {
	return len(m)
}

// Cols returns the number of columns
func (m Matrix64) Cols() int {
	if len(m) == 0 {
		return 0
	} // if

	return len(m[0])
}

// Dims return the dimensions of the matrix.
func (m Matrix64) Dims() (int, int) {
	return len(m), len(m[0])
}

// Clone clones a Matrix64
func (m Matrix64) Clone() Matrix64 {
	mat := NewMatrix64(m.Rows(), m.Cols())

	n := m.Rows() * m.Cols()
	if n > 0 {
		copy(mat[0][:n], m[0][:n])
	} // if

	return mat
}

// Copy to an existing matrix
func CopyTo(m Matrix64) (targetMat Matrix64) {
	n := m.Rows() * m.Cols()
	if n > 0 {
		copy(targetMat[0][:n], m[0][:n])
	}
	return
}

// Copy from an existing matrix
func CopyFrom(m Matrix64) (srcMat Matrix64) {
	n := m.Rows() * m.Cols()
	if n > 0 {
		copy(m[0][:n], srcMat[0][:n])
	}
	return
}

// IntRound clones the matrix into an integer matrix. 
func (m Matrix64) IntRound() IntMatrix {
	mat := NewIntMatrix(m.Rows(), m.Cols())
	rows, cols := m.Dims()
	for i := 0; i < rows; i++ {
		for j := 0; j < cols; j++ {
			mat[i][j] = iRound(m[i][j])
		}
	}
	return mat
}

// Swap rows i, j
func (m Matrix64) SwapRows(i, j int) {
	cols := m.Cols()
	for k := 0; k < cols; k++ {
		x := m[i][k]
		m[i][k] = m[j][k]
		m[j][k] = x
	}
}

// Swap columns i, j
func (m Matrix64) SwapCols(i, j int) {
	rows := m.Rows()
	for k := 0; k < rows; k++ {
		x := m[k][i]
		m[k][i] = m[k][j]
		m[k][j] = x
	}
}

// ReadCsvMatrix64  reads the matrix from an opened CSV file. 
func ReadCsvMatrix64(f *os.File) (m Matrix64) {
	read := csv.NewReader(io.Reader(f))
	data, err := read.ReadAll()
	if err != nil {
		fmt.Println("Failed to read from the CSV File(Maybe the file does not comply to the CSV standard defined in RFC 4180)")
	}
	rows := len(data)
	cols := len(data[0])
	m = NewMatrix64(rows, cols)
	for i := 0; i < rows; i++ {
		for j := 0; j < cols; j++ {
			x, _ := strconv.ParseFloat(data[i][j], 10)
			m[i][j] = float64(x)
		}
	}
	return
}

func (m Matrix64) Print() {
	rows, cols := m.Dims()
	for i := 0; i < rows; i++ {
		for j := 0; j < cols; j++ {
			fmt.Printf("%f ", m[i][j])
		}
		fmt.Println()
	}
}

// Product computes the product of two matrices. 
func (a Matrix64) Product(b Matrix64) Matrix64 {
	rows, cols := a.Dims()
	c := NewMatrix64(rows, cols)
	for i := 0; i < rows; i++ {
		for j := 0; j < cols; j++ {
			c[i][j] = 0
			for k := 0; k < cols; k++ {
				c[i][j] += a[i][k] * b[k][j]
			}
		}
	}
	return c
}

// CircleProduct computes circular product of two matrices. 
func (a Matrix64) CircleProduct(b Matrix64) Matrix64 {
	rows, cols := a.Dims()
	c := NewMatrix64(rows, cols)
	for i := 0; i < rows; i++ {
		for j := 0; j < rows; j++ {
			c[i][j] = 0
			for k := 0; k < cols; k++ {
				c[i][j] += min(a[i][k], b[k][j])
			}
		}
	}
	return c
}

// Transpose returns transposed matrix. 
func (a Matrix64) Transpose() Matrix64 {
	rows, cols := a.Dims()
	c := NewMatrix64(cols, rows)
	for i := 0; i < rows; i++ {
		for j := 0; j < cols; j++ {
			c[j][i] = a[i][j]
		}
	}
	return c
}

// IsSquare tests whether the matrix is square matrix. 
func (a Matrix64) IsSquare() bool {
	q := true
	rows, cols := a.Dims()
	if rows != cols {
		q = false
	}
	return q
}

// IsSymmetric tests whether the square matrix is symmetric. 
func (a Matrix64) IsSymmetric() bool {

	if !a.IsSquare() {
		panic("not a square matrix")
	}

	rows, cols := a.Dims()
	q := true
	for i := 0; i < rows && q; i++ {
		for j := 0; j < cols && q; j++ {
			if a[i][j] != a[j][i] {
				q = false
			}
		}
	}
	return q
}

// IsQ tests whether the matrix is a Q-matrix (columnwise). 
// See Kendall, 1971, for definition.
func (a Matrix64) IsQ() bool {
	rows, cols := a.Dims()
	q := true
	for j := 0; j < cols && q; j++ {
		//find peak in column j
		peak := -Inf
		peakPos := 0
		for i := 0; i < rows; i++ {
			if a[i][j] >= peak {
				peak = a[i][j]
				peakPos = i

			} else {
				break
			}
		}

		// now test whether further is nonincreasing
		for i := peakPos + 1; i < rows && q; i++ {
			if a[i][j] > a[i-1][j] {
				q = false
			}
		}
	}
	return q
}

// IsR tests whether the square matrix is a R-matrix (Robinson, columnwise). 
// See Kendall, 1971, for definition.
func (a Matrix64) IsR() bool {
	q := a.IsSymmetric()
	if q {
		q = a.IsQ()
	}
	return q
}
