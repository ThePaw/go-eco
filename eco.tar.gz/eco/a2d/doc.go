// Copyright 2012 - 2013 The Eco Authors. All rights reserved. See the LICENSE file.

// Posterior distribution of population density D inferred from abundance (=counts of individuals) A and sampling duration T. 
// T ~ N(μ, σ)
// A ~ Pois(T*D)
package a2d
