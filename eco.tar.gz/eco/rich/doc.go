// Copyright 2012 - 2013 The Eco Authors. All rights reserved. See the LICENSE file.

// Package rich implements a species richness estimation library.
package rich
