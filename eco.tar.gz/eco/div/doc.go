// Copyright 2012 - 2013 The Eco Authors. All rights reserved. See the LICENSE file.

// Package div implements a diversity / equitability (evenness) / inequality library.
package div
