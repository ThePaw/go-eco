// Package cmd contains some commands for (paleo)ecology.
package cmd

