// Copyright 2012 - 2013 The Eco Authors. All rights reserved. See the LICENSE file.

// Package sim implements a similarity / dissimilarity (distance) library.
package sim
